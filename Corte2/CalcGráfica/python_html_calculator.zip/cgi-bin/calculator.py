#!/usr/bin/env python3
import cgi

class Calculadora:
    def __init__(self, n1, n2):
        self.n1 = float(n1)
        self.n2 = float(n2)

    def sumar(self):
        return self.n1 + self.n2

    def restar(self):
        return self.n1 - self.n2

    def multiplicar(self):
        return self.n1 * self.n2

    def dividir(self):
        if self.n2 == 0:
            return "Error: división por cero"
        return self.n1 / self.n2

form = cgi.FieldStorage()
n1 = form.getvalue("num1", 0)
n2 = form.getvalue("num2", 0)
operacion = form.getvalue("operacion", "sumar")

calc = Calculadora(n1, n2)
resultado = ""

if operacion == "sumar":
    resultado = calc.sumar()
elif operacion == "restar":
    resultado = calc.restar()
elif operacion == "multiplicar":
    resultado = calc.multiplicar()
elif operacion == "dividir":
    resultado = calc.dividir()

print("Content-type: text/html\n")
print(f"""
<!DOCTYPE html>
<html>
<head><meta charset='UTF-8'><title>Resultado</title></head>
<body style='font-family:sans-serif;background:#e3f2fd;text-align:center;padding:50px'>
    <h1>Resultado: {resultado}</h1>
    <a href="/">Volver</a>
</body>
</html>
""")
